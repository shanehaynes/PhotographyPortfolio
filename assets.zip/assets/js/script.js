document.addEventListener("DOMContentLoaded", function () {
  let page = 1;
  let loading = false;

  window.addEventListener("scroll", function () {
    if (
      window.innerHeight + window.scrollY >= document.body.offsetHeight - 200 &&
      !loading
    ) {
      loading = true;
      page++;

      fetch(`?page=${page}`)
        .then((response) => response.text())
        .then((html) => {
          document
            .querySelector(".gallery")
            .insertAdjacentHTML("beforeend", html);
          loading = false;
        });
    }
  });
});
